var isTouch = "ontouchend" in document;
var downEvent = isTouch? "touchstart" : "mousedown";
var start = window.document.getElementById("start");
var optin = window.document.getElementById("optin");

optin.addEventListener(downEvent, function () {
    this.classList.toggle("selected");
    start.classList.toggle("disabled");
});

start.addEventListener(downEvent, function () {
    if (!this.classList.contains("disabled")) {
        localStorage.setItem(hereWelcomeDisclaimerKey, "true");
        window.location = hereStartUri;
    }
});
